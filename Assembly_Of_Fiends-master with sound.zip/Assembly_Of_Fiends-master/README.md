# Assembly_Of_Fiends
Project 5 for LMC 2700 (Fall 2018) 



This is a project for LMC 2700 "Intro to Computational Media"
